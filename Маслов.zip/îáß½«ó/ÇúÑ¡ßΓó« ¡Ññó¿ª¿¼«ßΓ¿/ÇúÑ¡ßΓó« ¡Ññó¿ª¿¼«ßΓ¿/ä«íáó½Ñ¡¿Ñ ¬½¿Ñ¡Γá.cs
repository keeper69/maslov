﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Агенство_недвижимости
{
    public partial class Добавление_клиента : Form
    {
        public Добавление_клиента()
        {
            InitializeComponent();
        }

        private void Добавление_клиента_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "экзаменDataSet1.Клиент". При необходимости она может быть перемещена или удалена.
            this.клиентTableAdapter.Fill(this.экзаменDataSet1.Клиент);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var db = new экзаменEntities())
            {
                if (textBox5.Text != "")
                {
                    var usern = new Клиент();
                    usern.id = int.Parse(textBox1.Text);
                    usern.Имя = textBox2.Text;
                    usern.Фамилия = textBox3.Text;
                    usern.Отчество = textBox4.Text;
                    usern.Номер_телефона = textBox5.Text;
                    usern.электронная_почта = textBox6.Text;
                    var a = int.Parse(textBox1.Text);
                    var usern1 = db.Клиент.FirstOrDefault(uch => uch.id == a);
                    if (usern1 == null)
                    {
                        db.Клиент.Add(usern);
                        db.SaveChanges();
                        MessageBox.Show("Данные успешно внесены");
                    }
                    else { MessageBox.Show("Такие данные уже есть"); }
                }
                {
                    this.Hide();
                }
            }
        }
    }
}
