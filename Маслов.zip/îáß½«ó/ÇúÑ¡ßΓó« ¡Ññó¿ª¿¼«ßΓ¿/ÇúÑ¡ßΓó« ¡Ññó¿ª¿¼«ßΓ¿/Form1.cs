﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Агенство_недвижимости
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "экзаменDataSet.Клиент". При необходимости она может быть перемещена или удалена.
            this.клиентTableAdapter.Fill(this.экзаменDataSet.Клиент);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Добавление_клиента fas = new Добавление_клиента();
            fas.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.клиентTableAdapter.Fill(this.экзаменDataSet.Клиент);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (var db = new экзаменEntities())
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int index = dataGridView1.SelectedRows[0].Index;
                    int id = 0;
                    bool converted = Int32.TryParse(dataGridView1[0, index].Value.ToString(), out id);
                    if (converted == false) return;
                    Клиент users = db.Клиент.Find(id);
                    db.Клиент.Remove(users);
                    db.SaveChanges();
                    MessageBox.Show("Строка удалены успешно");


                }
            }  
        }
    }
}
